module.exports = require('@wf/configs/lint-staged.config');
