export const transformNaNValue = (value: number) => (isNaN(value) ? undefined : value);
