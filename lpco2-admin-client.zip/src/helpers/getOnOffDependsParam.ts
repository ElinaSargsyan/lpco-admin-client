export function getOnOfDependsParam(param: boolean | number) {
  return param ? 'On' : 'Off';
}
