# How to add new Icon

**Video**: https://confluence.webbfontaine.com/display/~razmik.ispiryan/HOW+TO+ADD+ICONS+IN+WF-UI-TOOLS

**IcoMoon**: https://icomoon.io/app/#/select

## Step 1
  Watch the video and do all operations as shown in the video
## Step 2
  Run `yarn build` command to build all new fonts
## Step 3
Run `yarn start` command to check new Icon


