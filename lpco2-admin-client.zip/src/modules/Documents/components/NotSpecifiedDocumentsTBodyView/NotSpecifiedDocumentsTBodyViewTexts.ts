const ATT_DOCUMENT_CODE = 'Att Document Code';
const ATT_DOCUMENT_NAME = 'Att Document Name';
const ATT_DOCUMENT_NAME_IN_NL = 'Att Document Name in NL';
const SPECIFY_BUTTON_TEXT = 'Specify Now';

export default {
  ATT_DOCUMENT_CODE,
  ATT_DOCUMENT_NAME,
  ATT_DOCUMENT_NAME_IN_NL,
  SPECIFY_BUTTON_TEXT,
};
