import SpecifyDocumentView from './SpecifyDocumentView';

export default SpecifyDocumentView;
