import NotSpecifiedDocumentsView from './NotSpecifiedDocumentsView';

export default NotSpecifiedDocumentsView;
