import SpecifiedDocumentsView from './SpecifiedDocumentsView';

export default SpecifiedDocumentsView;
