import SpecifiedDocumentsTBodyView from './SpecifiedDocumentsTBodyView';

export default SpecifiedDocumentsTBodyView;
