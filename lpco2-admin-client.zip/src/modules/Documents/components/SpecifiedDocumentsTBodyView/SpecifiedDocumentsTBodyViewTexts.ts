const ATT_DOCUMENT_CODE = 'Att Document Code';
const ATT_DOCUMENT_NAME = 'Att Document Name';
const ATT_DOCUMENT_NAME_IN_NL = 'Att Document Name in NL';
const NATURE_OF_LICENSE = 'Nature of license';
const MINISTRY_OWNER_CODE = 'Ministry Owner Code';
const DEPARTMENT_OWNER_CODE = 'Department Owner Code';

export default {
  ATT_DOCUMENT_CODE,
  ATT_DOCUMENT_NAME,
  ATT_DOCUMENT_NAME_IN_NL,
  NATURE_OF_LICENSE,
  MINISTRY_OWNER_CODE,
  DEPARTMENT_OWNER_CODE,
};
