const HEADER_TITLE = 'Attached licenseTypes';
const NSPEC_DOC_SEARCH_FIELD_PLACEHOLDER = 'Documents Code';
const NSPEC_DOC_TITLE = 'Not Specified Documents';
const NSPEC_DOC_EMPTY_DATA_TITLE = 'No not specified documents yet';
const NSPEC_DOC_EMPTY_DATA_DESCRIPTION = 'This is place holder text. The basic dialog for tables';
const SPEC_DOC_TITLE = 'Specified Documents';
const SPEC_DOC_EMPTY_DATA_TITLE = 'No specified documents yet';
const SPEC_DOC_EMPTY_DATA_DESCRIPTION = 'This is place holder text. The basic dialog for tables';

export default {
  HEADER_TITLE,
  NSPEC_DOC_SEARCH_FIELD_PLACEHOLDER,
  NSPEC_DOC_TITLE,
  NSPEC_DOC_EMPTY_DATA_TITLE,
  NSPEC_DOC_EMPTY_DATA_DESCRIPTION,
  SPEC_DOC_TITLE,
  SPEC_DOC_EMPTY_DATA_TITLE,
  SPEC_DOC_EMPTY_DATA_DESCRIPTION,
};
