import SpecifyDocument from './SpecifyDocument';

export default SpecifyDocument;
