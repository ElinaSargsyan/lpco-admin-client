const SPECIFY_DOCUMENT_TITLE = 'New License type';

export default {
  SPECIFY_DOCUMENT_TITLE,
};
