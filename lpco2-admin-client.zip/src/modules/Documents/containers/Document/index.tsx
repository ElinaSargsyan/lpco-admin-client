import Document from './Document';

export default Document;
