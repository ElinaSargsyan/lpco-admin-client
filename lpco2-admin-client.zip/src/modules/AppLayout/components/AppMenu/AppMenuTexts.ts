const HOME = 'Home';
const MINISTRIES = 'Ministries';
const DOCUMENTS = 'Documents';
const LICENSES = 'Licenses';

export default {
  HOME,
  MINISTRIES,
  DOCUMENTS,
  LICENSES,
};
