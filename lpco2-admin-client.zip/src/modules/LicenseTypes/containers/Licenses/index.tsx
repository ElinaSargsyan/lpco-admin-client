export { default } from './Licenses';
