export { default } from './LPStampSectionContainer';
