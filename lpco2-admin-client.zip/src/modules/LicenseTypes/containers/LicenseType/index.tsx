export { default } from './LicenseType';
