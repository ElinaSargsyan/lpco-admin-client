export { default } from './LWTransitionPopupContent';
