export { default } from './LWApprovalSectionContainer';
