export const taxCodeErrorField = 'Tax code need to have minimum 1 and maximum 3 character';
