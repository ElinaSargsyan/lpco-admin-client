export { default } from './LicenseFeesView';
