import { APPNAME } from '../../../../constatnts';

const APPLICATION_FEES_TITLE_TEXT = `${APPNAME} Application Fee/s`;
const EXTENTION_FEES_TITLE_TEXT = `${APPNAME} Extention Fee/s`;

export default {
  APPLICATION_FEES_TITLE_TEXT,
  EXTENTION_FEES_TITLE_TEXT,
};
