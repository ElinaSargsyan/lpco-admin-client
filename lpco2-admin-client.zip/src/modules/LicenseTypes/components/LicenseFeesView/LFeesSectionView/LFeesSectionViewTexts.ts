const TABLE_HEADER_CODE_TITLE = 'Code';
const TABLE_HEADER_DESCRIPTION_TITLE = 'Description';
const TABLE_HEADER_AMOUNT_TITLE = 'Value';
const TABLE_NO_DATA_TITLE = 'No applicable fees yet';
const TABLE_NO_DATA_DESCRIPTION = 'This is place holder text. The basic dialog for tables';

export default {
  TABLE_HEADER_CODE_TITLE,
  TABLE_HEADER_DESCRIPTION_TITLE,
  TABLE_HEADER_AMOUNT_TITLE,
  TABLE_NO_DATA_TITLE,
  TABLE_NO_DATA_DESCRIPTION,
};
