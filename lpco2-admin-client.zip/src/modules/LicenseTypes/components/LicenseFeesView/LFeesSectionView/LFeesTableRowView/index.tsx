export { default } from './LFeesTableRowView';
