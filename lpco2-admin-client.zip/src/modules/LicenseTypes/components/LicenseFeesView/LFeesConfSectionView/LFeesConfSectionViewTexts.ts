const TITLE_TEXT = 'Fees';
const PAYMENT_FLOW_TEXT = 'Payment Flow';
const PAYMENT_FLOW_PLACHOLDER_TEXT = 'Choose Payment Flow';

export default {
  TITLE_TEXT,
  PAYMENT_FLOW_TEXT,
  PAYMENT_FLOW_PLACHOLDER_TEXT,
};
