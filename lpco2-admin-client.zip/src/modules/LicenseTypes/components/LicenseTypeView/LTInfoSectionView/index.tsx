export { default } from './LTInfoSectionView';
