export interface ILTInfoSectionView {
  licenseTypeCode?: string;
  licenseTypeName?: string;
  licenseTypeNameInNationalLang?: string;
  licenseTypeNature?: string;
  ministryCode?: string;
  departmentCode?: string;
}
