export { default } from './LTValiditySectionView';
