import type { UseFormReturn } from 'react-hook-form';

export interface ILTValiditySectionViewProps {
  form?: UseFormReturn;
}
