const TITLE_TEXT = 'License Type Configurations';
const COUNTRY_OF_EXPORT_OR_ENABLED_TEXT = 'Show Country Export/Import On License';
const FLOW_ENABLED_TEXT = 'Show Flow On License';
const FLOW_TEXT = 'Flow';
const TYPE_OF_USE_ENABLED_TEXT = 'Show Type of Use On License';
const TYPE_OF_USE_TEXT = 'Default Type of Use';

export default {
  TITLE_TEXT,
  COUNTRY_OF_EXPORT_OR_ENABLED_TEXT,
  FLOW_ENABLED_TEXT,
  FLOW_TEXT,
  TYPE_OF_USE_ENABLED_TEXT,
  TYPE_OF_USE_TEXT,
};
