export { default } from './LicenseTypeView';
