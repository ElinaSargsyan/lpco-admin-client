export { default } from './LicenseTypeTabView';
