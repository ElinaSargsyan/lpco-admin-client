import NotConfiguredLicensesView from './NotConfiguredLicensesView';

export default NotConfiguredLicensesView;
