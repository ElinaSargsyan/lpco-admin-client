export { default } from './LicenseAttDocView';
