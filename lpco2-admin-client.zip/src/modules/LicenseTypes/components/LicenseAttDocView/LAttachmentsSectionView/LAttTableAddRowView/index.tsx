export { default } from './LAttTableAddRowView';
