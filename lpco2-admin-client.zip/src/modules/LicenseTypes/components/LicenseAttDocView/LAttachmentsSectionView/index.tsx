export { default } from './LAttachmentsSectionView';
