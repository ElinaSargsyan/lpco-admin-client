const TITLE_TEXT = 'Configurable Operations After Approval';
const UPDATE_APPROVE_OPENABLED_TEXT = 'Update Approve Operation';
const SUSPEND_OPENABLED_TEXT = 'Suspend & Activate Operation';
const CANCEL_OPENABLED_TEXT = 'Cancel Operation';

export default {
  TITLE_TEXT,
  UPDATE_APPROVE_OPENABLED_TEXT,
  SUSPEND_OPENABLED_TEXT,
  CANCEL_OPENABLED_TEXT,
};
