export { default } from './LWConfSectionView';
