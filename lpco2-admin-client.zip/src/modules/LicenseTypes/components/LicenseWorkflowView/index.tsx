export { default } from './LicenseWorkflowView';
