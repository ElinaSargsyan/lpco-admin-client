export { default } from './LWInspectionSectionView';
