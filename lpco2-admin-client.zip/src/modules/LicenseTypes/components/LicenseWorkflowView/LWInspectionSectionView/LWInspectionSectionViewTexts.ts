const TITLE_TEXT = 'Inspection';

export default {
  TITLE_TEXT,
};
