export { default } from './LWTransitionPopupContentView';
