export { default } from './LWApprovalSectionView';
