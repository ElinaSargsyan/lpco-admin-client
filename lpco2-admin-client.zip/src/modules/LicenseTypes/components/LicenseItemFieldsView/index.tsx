export { default } from './LicenseItemFieldsView';
