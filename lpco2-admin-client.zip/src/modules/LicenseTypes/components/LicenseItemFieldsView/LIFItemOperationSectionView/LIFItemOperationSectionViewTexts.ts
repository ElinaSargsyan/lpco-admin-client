const TITLE_TEXT = 'Item Operation';
const ADD_ITEM_TEXT = 'Add Item';
const EDIT_ITEM_TEXT = 'Edit Item';
const DELETE_ITEM_TEXT = 'Delete Item';
const ACTIONS_NAME = 'Actions Name';
const ENABLE_ON_QUERIED = 'Enable on Queried';
const ENABLE_ON_OGA_EDIT = 'Enable on OGA Edit';

export default {
  TITLE_TEXT,
  ADD_ITEM_TEXT,
  EDIT_ITEM_TEXT,
  DELETE_ITEM_TEXT,
  ACTIONS_NAME,
  ENABLE_ON_QUERIED,
  ENABLE_ON_OGA_EDIT,
};
