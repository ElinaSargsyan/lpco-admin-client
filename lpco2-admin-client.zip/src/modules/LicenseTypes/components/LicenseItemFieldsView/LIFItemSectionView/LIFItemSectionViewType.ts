import type { UseFormReturn } from 'react-hook-form';

export interface ILIFItemSectionViewProps {
  form?: UseFormReturn;
}
