export { default } from './LIFQuotaSectionView';
