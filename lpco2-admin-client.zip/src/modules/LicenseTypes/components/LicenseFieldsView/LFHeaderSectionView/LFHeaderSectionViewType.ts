import type { UseFormReturn } from 'react-hook-form';

export interface ILFHeaderSectionViewProps {
  form?: UseFormReturn;
}
