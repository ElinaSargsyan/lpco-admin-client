export { default } from './LFHeaderSectionView';
