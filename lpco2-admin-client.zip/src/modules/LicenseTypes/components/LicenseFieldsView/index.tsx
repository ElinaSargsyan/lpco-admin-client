export { default } from './LicenseFieldsView';
