export { default } from './GeneralForm';
