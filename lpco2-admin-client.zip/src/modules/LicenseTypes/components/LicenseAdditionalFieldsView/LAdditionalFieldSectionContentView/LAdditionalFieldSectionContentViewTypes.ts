import { type AdditionalFieldsTabs } from '../../../constants';

export interface ILAdditionalFieldSectionContentViewProps {
  tab: keyof typeof AdditionalFieldsTabs;
}
