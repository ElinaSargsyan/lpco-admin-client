export { default } from './LicensePrintoutView';
