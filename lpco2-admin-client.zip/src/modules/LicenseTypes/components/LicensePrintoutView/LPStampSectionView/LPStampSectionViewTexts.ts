const TITLE_TEXT = 'Add Signature and Stamp';

export default {
  TITLE_TEXT,
};
