export { default } from './LPStampSectionView';
