export { default } from './ConfiguredLicensesTBodyView';
