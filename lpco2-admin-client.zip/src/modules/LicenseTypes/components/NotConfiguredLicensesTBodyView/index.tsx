import NotConfiguredLicensesTBodyView from './NotConfiguredLicensesTBodyView';

export default NotConfiguredLicensesTBodyView;
