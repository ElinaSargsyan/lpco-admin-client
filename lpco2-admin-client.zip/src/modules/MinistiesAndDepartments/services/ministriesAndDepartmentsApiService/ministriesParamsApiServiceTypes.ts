export interface IMinistriesParams {
  offset?: number;
  limit?: number;
  searchValue?: string;
}

export interface IMinistryParams {
  code: string;
}
