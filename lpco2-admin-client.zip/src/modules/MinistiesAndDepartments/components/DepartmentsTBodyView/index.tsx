import DepartmentsTBodyView from './DepartmentsTBodyView';

export default DepartmentsTBodyView;
