const DIPARTMENT_NAME = 'Department Name';
const DEPARTMENT_CODE = 'Department Code';
const DEPARTMENT_EMAIL = 'Department Email';

export default {
  DIPARTMENT_NAME,
  DEPARTMENT_CODE,
  DEPARTMENT_EMAIL,
};
