const MINISTRY_NAME = 'Ministry Name';
const MINISTRY_CODE = 'Ministry Code';
const MINISTRY_ADDRESS = 'Address';
const DEPARTMENT_NAME = 'Department Name';
const DEPARTMENT_CODE = 'Department Code';
const DEPARTMENT_EMAIL = 'Department Email';

export default {
  MINISTRY_NAME,
  MINISTRY_CODE,
  MINISTRY_ADDRESS,
  DEPARTMENT_NAME,
  DEPARTMENT_CODE,
  DEPARTMENT_EMAIL,
};
