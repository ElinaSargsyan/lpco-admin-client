import MinistriesTBodyView from './MinistriesTBodyView';

export default MinistriesTBodyView;
