export { ministries } from './store/slices';
export { watchMinistriesSaga } from './store/sagas';
