const MINISTRY_INFO = 'Ministry Information';
const MINISTRY_CODE = 'Ministry Code';
const PHONE = 'Phone';
const DEPARTMENT_ADDRESS = 'Address';
const MINISTRY_NAME = 'Ministry Name';
const MINISTRY_NAME_IN_NL = 'Ministry Name in NL';
const EMAEL = 'eMail';
const ASSOCIATED_DEPARTMENTS = 'Associated Departments';

export default {
  MINISTRY_INFO,
  MINISTRY_CODE,
  PHONE,
  DEPARTMENT_ADDRESS,
  MINISTRY_NAME,
  MINISTRY_NAME_IN_NL,
  EMAEL,
  ASSOCIATED_DEPARTMENTS,
};
