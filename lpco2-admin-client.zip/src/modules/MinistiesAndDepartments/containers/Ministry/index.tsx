import Ministry from './Ministry';

export default Ministry;
