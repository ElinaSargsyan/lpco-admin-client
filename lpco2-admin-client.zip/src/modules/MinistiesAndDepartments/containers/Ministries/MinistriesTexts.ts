const MINISTRY_FILTER_PLACEHOLDER = 'Enter ministry name or code';
const MINISTRIES_HEADER_TITLE = 'Ministries';
const MINISTRIES_EMPTY_DATA_TITLE = 'No ministry data yet';
const MINISTRIES_EMPTY_DATA_DESCRIPTION = 'This is place holder text. The basic dialog for tables';

export default {
  MINISTRY_FILTER_PLACEHOLDER,
  MINISTRIES_HEADER_TITLE,
  MINISTRIES_EMPTY_DATA_TITLE,
  MINISTRIES_EMPTY_DATA_DESCRIPTION,
};
