import Ministries from './Ministries';

export default Ministries;
