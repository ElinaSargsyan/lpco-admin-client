import Department from './Department';

export default Department;
