export { default } from './SwitcherControllerRenderHOC';
