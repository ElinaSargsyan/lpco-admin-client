import SpecifiedDocumentsHOC from './SpecifiedDocumentsHOC';

export default SpecifiedDocumentsHOC;
