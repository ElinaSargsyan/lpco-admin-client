import { PUBLIC_PATH } from '../config';

export const appPaths = {
  indexPath: PUBLIC_PATH,
  ministries: `${PUBLIC_PATH}ministries`,
  attachedDocuments: `${PUBLIC_PATH}attachedDocuments`,
  licenses: `${PUBLIC_PATH}licenses`,
};
