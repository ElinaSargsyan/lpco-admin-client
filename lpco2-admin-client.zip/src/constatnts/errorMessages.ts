export const mandatoryField = 'This field is mandatory';
export const zeroOrPositive = 'This field should be only 0 or positive';
export const onlyPositive = 'The field should contain only positive values';
export const countMoreCharacter = (count: number) => `Field should contain ${count} or more character`;
export const countLessCharacter = (count: number) => `Field should contain ${count} or less character`;
