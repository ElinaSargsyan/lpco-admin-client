export interface ISectionBodyProps extends IWithReactChildren {
  className?: string;
}
