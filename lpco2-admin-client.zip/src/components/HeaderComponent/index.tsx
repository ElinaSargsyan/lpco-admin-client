export { default } from './HeaderComponent';
