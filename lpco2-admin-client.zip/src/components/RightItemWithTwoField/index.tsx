export { default } from './RightItemWithTwoField';
