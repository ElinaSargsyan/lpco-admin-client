export { default } from './InfoContent';
