export interface ITableCellWithErrorMessageProps extends IWithReactChildren {
  className?: string;
}
