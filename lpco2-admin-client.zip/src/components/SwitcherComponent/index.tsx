export { default } from './SwitcherComponent';
