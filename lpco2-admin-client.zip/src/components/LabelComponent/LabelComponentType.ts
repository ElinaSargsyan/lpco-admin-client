export interface ILabelComponentProps extends IWithReactChildren {
  icon?: string;
}
