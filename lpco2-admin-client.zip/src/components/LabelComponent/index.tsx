export { default } from './LabelComponent';
