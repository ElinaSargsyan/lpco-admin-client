export { default } from './AccessDenied';
