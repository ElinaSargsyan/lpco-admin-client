export { default } from './TableComponent';
