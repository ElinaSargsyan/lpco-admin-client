export { default } from './ErrorsComponent';
