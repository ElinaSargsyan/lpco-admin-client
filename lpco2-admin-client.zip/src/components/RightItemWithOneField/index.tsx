export { default } from './RightItemWithOneField';
