export { default } from './TabContentSection';
