export interface ITabContentSection extends IWithReactChildren {
  title: string;
}
