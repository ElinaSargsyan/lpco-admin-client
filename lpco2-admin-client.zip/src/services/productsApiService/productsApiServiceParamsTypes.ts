export interface IProductsParams {
  code?: string;
}
