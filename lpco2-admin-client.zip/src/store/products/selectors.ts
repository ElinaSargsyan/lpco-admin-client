import type { RootState } from '../index';

export const productsSelector = (state: RootState) => state.products;
