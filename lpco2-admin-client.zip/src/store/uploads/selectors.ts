import type { RootState } from '../index';

export const uploadsDataSelector = (state: RootState) => state.uploads.data;
