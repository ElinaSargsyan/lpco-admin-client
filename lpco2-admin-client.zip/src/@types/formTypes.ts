export interface IControllerField {
  onChange: () => void;
  value: boolean;
}
