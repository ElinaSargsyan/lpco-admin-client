declare module '@wf/keycloak-axios-provider';
